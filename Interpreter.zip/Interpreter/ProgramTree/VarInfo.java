package Interpreter.ProgramTree;

public class VarInfo {

}
