package Interpreter.ProgramTree;

public class FunctionSymbolTable {

}
