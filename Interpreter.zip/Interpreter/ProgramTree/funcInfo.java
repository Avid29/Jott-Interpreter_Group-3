package Interpreter.ProgramTree;

public class funcInfo {

}
